import argparse
import itertools
import string
import sys
import os

def generate_combinations(chars, min_length, max_length, output_file):
    """Generate all possible combinations of the given characters within the length range."""
    try:
        with open(output_file, 'w') as f:
            for length in range(min_length, max_length + 1):
                print(f"Generating combinations of length {length}...")
                count = 0
                for combo in itertools.product(chars, repeat=length):
                    password = ''.join(combo)
                    f.write(password + '\n')
                    count += 1
                    if count % 1000000 == 0:  # Print progress every million combinations
                        print(f"Generated {count:,} combinations of length {length}")
                print(f"Completed length {length}, generated {count:,} combinations")
    except KeyboardInterrupt:
        print("\nGeneration interrupted by user")
    except Exception as e:
        print(f"Error occurred: {e}")

def generate_mutations(base_words, output_file):
    """Generate common mutations of the given base words."""
    mutations = []
    
    common_suffixes = ['123', '1234', '12345', '123456', '2023', '2024', '!', '@', '#', '$', '%', '1!', '1@']
    common_prefixes = ['123', 'admin', 'user', 'pass', 'pw']
    
    try:
        with open(output_file, 'w') as f:
            for word in base_words:
                word = word.strip()
                # Add original word
                mutations.append(word)
                
                # Add lowercase, uppercase, and capitalized versions
                mutations.append(word.lower())
                mutations.append(word.upper())
                mutations.append(word.capitalize())
                
                # Add common suffixes
                for suffix in common_suffixes:
                    mutations.append(word + suffix)
                    mutations.append(word.lower() + suffix)
                    mutations.append(word.upper() + suffix)
                    mutations.append(word.capitalize() + suffix)
                
                # Add common prefixes
                for prefix in common_prefixes:
                    mutations.append(prefix + word)
                    mutations.append(prefix + word.lower())
                    mutations.append(prefix + word.upper())
                    mutations.append(prefix + word.capitalize())
                
                # Add letter to number substitutions
                l33t_map = {'a': '4', 'e': '3', 'i': '1', 'o': '0', 's': '5', 't': '7'}
                l33t_word = ''
                for char in word.lower():
                    l33t_word += l33t_map.get(char, char)
                if l33t_word != word.lower():
                    mutations.append(l33t_word)
                    
                    # Add l33t with common suffixes
                    for suffix in common_suffixes:
                        mutations.append(l33t_word + suffix)
            
            # Write unique mutations to the file
            unique_mutations = list(set(mutations))
            for mutation in unique_mutations:
                f.write(mutation + '\n')
                
            print(f"Generated {len(unique_mutations)} unique password mutations")
    
    except Exception as e:
        print(f"Error occurred: {e}")

def main():
    parser = argparse.ArgumentParser(description='Password Wordlist Generator')
    subparsers = parser.add_subparsers(dest='command', help='Command')
    
    # Combinations generator
    combo_parser = subparsers.add_parser('combinations', help='Generate all possible combinations')
    combo_parser.add_argument('--chars', '-c', default='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', 
                            help='Characters to use for combinations')
    combo_parser.add_argument('--min-length', '-min', type=int, default=1, help='Minimum password length')
    combo_parser.add_argument('--max-length', '-max', type=int, default=8, help='Maximum password length')
    combo_parser.add_argument('--output', '-o', default='wordlist.txt', help='Output file')
    
    # Common character sets
    combo_parser.add_argument('--digits-only', '-d', action='store_true', help='Use only digits (0-9)')
    combo_parser.add_argument('--lowercase-only', '-l', action='store_true', help='Use only lowercase letters (a-z)')
    combo_parser.add_argument('--uppercase-only', '-u', action='store_true', help='Use only uppercase letters (A-Z)')
    combo_parser.add_argument('--special-chars', '-s', action='store_true', 
                            help='Include special characters (!@#$%^&*()-_=+[]{}|;:,.<>?/)')
    
    # Mutations generator
    mutation_parser = subparsers.add_parser('mutations', help='Generate mutations of base words')
    mutation_parser.add_argument('--input', '-i', required=True, help='Input file with base words')
    mutation_parser.add_argument('--output', '-o', default='mutations.txt', help='Output file')
    
    args = parser.parse_args()
    
    if args.command == 'combinations':
        chars = args.chars
        
        if args.digits_only:
            chars = string.digits
        elif args.lowercase_only:
            chars = string.ascii_lowercase
        elif args.uppercase_only:
            chars = string.ascii_uppercase
            
        if args.special_chars:
            chars += '!@#$%^&*()-_=+[]{}|;:,.<>?/'
            
        print(f"Generating combinations with character set: {chars}")
        print(f"Length range: {args.min_length} to {args.max_length}")
        print(f"Output file: {args.output}")
        
        # Estimate the number of combinations
        total_combinations = sum(len(chars) ** length for length in range(args.min_length, args.max_length + 1))
        print(f"Estimated number of combinations: {total_combinations:,}")
        
        # Check if the file will be too large
        estimated_size_bytes = total_combinations * (args.max_length + 1)  # +1 for newline
        estimated_size_mb = estimated_size_bytes / (1024 * 1024)
        estimated_size_gb = estimated_size_mb / 1024
        
        print(f"Estimated file size: {estimated_size_mb:.2f} MB ({estimated_size_gb:.2f} GB)")
        
        if estimated_size_gb > 1:
            confirm = input("Warning: The output file might be very large. Continue? (y/n): ")
            if confirm.lower() != 'y':
                print("Operation cancelled")
                return
        
        generate_combinations(chars, args.min_length, args.max_length, args.output)
        
    elif args.command == 'mutations':
        if not os.path.exists(args.input):
            print(f"Input file not found: {args.input}")
            return
            
        with open(args.input, 'r') as f:
            base_words = f.readlines()
            
        print(f"Generating mutations for {len(base_words)} base words")
        print(f"Output file: {args.output}")
        
        generate_mutations(base_words, args.output)
    
    else:
        parser.print_help()

if __name__ == "__main__":
    main() 