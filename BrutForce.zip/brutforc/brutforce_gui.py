import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog, messagebox
import threading
import time
import os
import datetime
from hash_functions import get_hash_function
from brutforce import BruteForce, PasswordAnalyzer, RainbowTable

class BruteForceGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Brute Force Password Cracker")
        self.root.geometry("900x700")
        self.root.resizable(True, True)
        
        self.brute_forcer = BruteForce()
        self.attack_thread = None
        self.running = False
        
        self.create_widgets()
        
    def create_widgets(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        basic_frame = ttk.Frame(self.notebook)
        self.notebook.add(basic_frame, text="Basic Settings")
        
        advanced_frame = ttk.Frame(self.notebook)
        self.notebook.add(advanced_frame, text="Advanced Settings")
        
        user_info_frame = ttk.Frame(self.notebook)
        self.notebook.add(user_info_frame, text="User Information")
        
        results_frame = ttk.Frame(self.notebook)
        self.notebook.add(results_frame, text="Results")
        
        self.setup_basic_tab(basic_frame)
        
        self.setup_advanced_tab(advanced_frame)
        
        self.setup_user_info_tab(user_info_frame)
        
        self.setup_results_tab(results_frame)
        
        control_frame = ttk.Frame(self.root)
        control_frame.pack(fill=tk.X, padx=10, pady=10)
        
        self.start_btn = ttk.Button(control_frame, text="Start Attack", command=self.start_attack)
        self.start_btn.pack(side=tk.LEFT, padx=5)
        
        self.stop_btn = ttk.Button(control_frame, text="Stop Attack", command=self.stop_attack, state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=5)
        
        self.view_log_btn = ttk.Button(control_frame, text="View Log", command=self.view_log, state=tk.DISABLED)
        self.view_log_btn.pack(side=tk.LEFT, padx=5)
    
    def setup_basic_tab(self, parent):
        main_frame = ttk.Frame(parent)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        target_frame = ttk.LabelFrame(main_frame, text="Target")
        target_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(target_frame, text="Target Value:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.target_entry = ttk.Entry(target_frame, width=50)
        self.target_entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        
        ttk.Label(target_frame, text="Hash Type:").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        self.hash_type = ttk.Combobox(target_frame, 
                                     values=["plaintext", "md5", "sha1", "sha256", "sha512", "ntlm", "base64"])
        self.hash_type.current(0)
        self.hash_type.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)
        
        mode_frame = ttk.LabelFrame(main_frame, text="Attack Mode")
        mode_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.mode_var = tk.StringVar(value="3")
        
        ttk.Radiobutton(mode_frame, text="Digits only (0-9)", variable=self.mode_var, value="1").grid(
            row=0, column=0, padx=5, pady=5, sticky=tk.W)
        ttk.Radiobutton(mode_frame, text="Letters only (a-zA-Z)", variable=self.mode_var, value="2").grid(
            row=0, column=1, padx=5, pady=5, sticky=tk.W)
        ttk.Radiobutton(mode_frame, text="All characters", variable=self.mode_var, value="3").grid(
            row=1, column=0, padx=5, pady=5, sticky=tk.W)
        ttk.Radiobutton(mode_frame, text="Manual mode (step-by-step)", variable=self.mode_var, value="4").grid(
            row=1, column=1, padx=5, pady=5, sticky=tk.W)
        
        options_frame = ttk.LabelFrame(main_frame, text="Options")
        options_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(options_frame, text="Max Password Length:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.length_var = tk.StringVar(value="8")
        self.length_spinbox = ttk.Spinbox(options_frame, from_=1, to=16, textvariable=self.length_var, width=5)
        self.length_spinbox.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        
        ttk.Label(options_frame, text="Number of Threads:").grid(row=0, column=2, padx=5, pady=5, sticky=tk.W)
        self.threads_var = tk.StringVar(value=str(max(1, os.cpu_count() - 1)))
        self.threads_spinbox = ttk.Spinbox(options_frame, from_=1, to=32, textvariable=self.threads_var, width=5)
        self.threads_spinbox.grid(row=0, column=3, padx=5, pady=5, sticky=tk.W)
        
        ttk.Label(options_frame, text="Dictionary File:").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        self.dictionary_var = tk.StringVar()
        dictionary_entry = ttk.Entry(options_frame, textvariable=self.dictionary_var, width=40)
        dictionary_entry.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W, columnspan=2)
        
        browse_btn = ttk.Button(options_frame, text="Browse...", command=self.browse_dictionary)
        browse_btn.grid(row=1, column=3, padx=5, pady=5)
        
        logging_frame = ttk.LabelFrame(main_frame, text="Logging")
        logging_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.log_enabled_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(logging_frame, text="Enable Logging", variable=self.log_enabled_var).grid(
            row=0, column=0, padx=5, pady=5, sticky=tk.W)
        
        ttk.Label(logging_frame, text="Log File:").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        self.log_file_var = tk.StringVar()
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        self.log_file_var.set(f"brutforce_{timestamp}.log")
        log_file_entry = ttk.Entry(logging_frame, textvariable=self.log_file_var, width=40)
        log_file_entry.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W, columnspan=2)
        
        log_browse_btn = ttk.Button(logging_frame, text="Browse...", command=self.browse_log_file)
        log_browse_btn.grid(row=1, column=3, padx=5, pady=5)
        
        ttk.Label(logging_frame, text="Log Frequency:").grid(row=2, column=0, padx=5, pady=5, sticky=tk.W)
        self.log_frequency_var = tk.StringVar(value="1000")
        log_freq_spinbox = ttk.Spinbox(logging_frame, from_=1, to=100000, textvariable=self.log_frequency_var, width=10)
        log_freq_spinbox.grid(row=2, column=1, padx=5, pady=5, sticky=tk.W)
        
        self.log_passwords_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(logging_frame, text="Log Passwords (Warning: creates large logs)", 
                       variable=self.log_passwords_var).grid(
            row=3, column=0, columnspan=4, padx=5, pady=5, sticky=tk.W)
    
    def setup_advanced_tab(self, parent):
        main_frame = ttk.Frame(parent)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        attack_frame = ttk.LabelFrame(main_frame, text="Advanced Attack Methods")
        attack_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.smart_attack_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(attack_frame, text="Smart Attack (uses target analysis and user info)", 
                       variable=self.smart_attack_var).grid(
            row=0, column=0, columnspan=2, padx=5, pady=5, sticky=tk.W)
        
        self.hybrid_attack_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(attack_frame, text="Hybrid Attack (dictionary + mutations)", 
                       variable=self.hybrid_attack_var).grid(
            row=1, column=0, columnspan=2, padx=5, pady=5, sticky=tk.W)
        
        self.targeted_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(attack_frame, text="Targeted Brute Force (optimized character sets)", 
                       variable=self.targeted_var).grid(
            row=2, column=0, columnspan=2, padx=5, pady=5, sticky=tk.W)
        
        self.optimize_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(attack_frame, text="Optimize charset based on dictionary analysis", 
                       variable=self.optimize_var).grid(
            row=3, column=0, columnspan=2, padx=5, pady=5, sticky=tk.W)
        
        rainbow_frame = ttk.LabelFrame(main_frame, text="Rainbow Table")
        rainbow_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(rainbow_frame, text="Rainbow Table File:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.rainbow_table_var = tk.StringVar()
        rainbow_entry = ttk.Entry(rainbow_frame, textvariable=self.rainbow_table_var, width=40)
        rainbow_entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        
        rainbow_browse_btn = ttk.Button(rainbow_frame, text="Browse...", command=self.browse_rainbow_table)
        rainbow_browse_btn.grid(row=0, column=2, padx=5, pady=5)
        
        self.generate_rainbow_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(rainbow_frame, text="Generate Rainbow Table from Dictionary", 
                       variable=self.generate_rainbow_var).grid(
            row=1, column=0, columnspan=2, padx=5, pady=5, sticky=tk.W)
        
        ttk.Label(rainbow_frame, text="Save Generated Table to:").grid(row=2, column=0, padx=5, pady=5, sticky=tk.W)
        self.save_rainbow_var = tk.StringVar()
        save_rainbow_entry = ttk.Entry(rainbow_frame, textvariable=self.save_rainbow_var, width=40)
        save_rainbow_entry.grid(row=2, column=1, padx=5, pady=5, sticky=tk.W)
        
        save_rainbow_browse_btn = ttk.Button(rainbow_frame, text="Browse...", command=self.browse_save_rainbow)
        save_rainbow_browse_btn.grid(row=2, column=2, padx=5, pady=5)
    
    def setup_user_info_tab(self, parent):
        main_frame = ttk.Frame(parent)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        info_frame = ttk.LabelFrame(main_frame, text="User Information for Smart Attack")
        info_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(info_frame, text="Full Name:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.user_name_var = tk.StringVar()
        ttk.Entry(info_frame, textvariable=self.user_name_var, width=30).grid(
            row=0, column=1, padx=5, pady=5, sticky=tk.W)
        
        ttk.Label(info_frame, text="Birth Date (DDMMYYYY):").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        self.user_birth_var = tk.StringVar()
        ttk.Entry(info_frame, textvariable=self.user_birth_var, width=30).grid(
            row=1, column=1, padx=5, pady=5, sticky=tk.W)
        
        ttk.Label(info_frame, text="Username:").grid(row=2, column=0, padx=5, pady=5, sticky=tk.W)
        self.user_username_var = tk.StringVar()
        ttk.Entry(info_frame, textvariable=self.user_username_var, width=30).grid(
            row=2, column=1, padx=5, pady=5, sticky=tk.W)
        
        ttk.Label(info_frame, text="Company:").grid(row=3, column=0, padx=5, pady=5, sticky=tk.W)
        self.user_company_var = tk.StringVar()
        ttk.Entry(info_frame, textvariable=self.user_company_var, width=30).grid(
            row=3, column=1, padx=5, pady=5, sticky=tk.W)
        
        help_text = ("This information will be used to generate smart password suggestions "
                    "based on common patterns. For example, if a person's name is 'John Smith' "
                    "and they were born in 1990, passwords like 'john1990', 'jsmith', etc. "
                    "will be tried first.\n\n"
                    "Note: This information is only used locally and is not stored or transmitted.")
        
        help_label = ttk.Label(info_frame, text=help_text, wraplength=400, justify="left")
        help_label.grid(row=4, column=0, columnspan=2, padx=10, pady=10, sticky=tk.W)
    
    def setup_results_tab(self, parent):
        main_frame = ttk.Frame(parent)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        progress_frame = ttk.LabelFrame(main_frame, text="Progress")
        progress_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.progress_var = tk.StringVar(value="Ready to start")
        ttk.Label(progress_frame, textvariable=self.progress_var).pack(anchor=tk.W, padx=5, pady=5)
        
        self.attempts_var = tk.StringVar(value="Attempts: 0")
        ttk.Label(progress_frame, textvariable=self.attempts_var).pack(anchor=tk.W, padx=5, pady=5)
        
        self.speed_var = tk.StringVar(value="Speed: 0 passwords/s")
        ttk.Label(progress_frame, textvariable=self.speed_var).pack(anchor=tk.W, padx=5, pady=5)
        
        self.time_var = tk.StringVar(value="Elapsed Time: 0s")
        ttk.Label(progress_frame, textvariable=self.time_var).pack(anchor=tk.W, padx=5, pady=5)
        
        result_frame = ttk.LabelFrame(main_frame, text="Results")
        result_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.result_text = scrolledtext.ScrolledText(result_frame, wrap=tk.WORD, height=15)
        self.result_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.result_text.config(state=tk.DISABLED)
        
    def browse_dictionary(self):
        filename = filedialog.askopenfilename(
            title="Select Dictionary File",
            filetypes=(("Text files", "*.txt"), ("All files", "*.*"))
        )
        if filename:
            self.dictionary_var.set(filename)
    
    def browse_log_file(self):
        filename = filedialog.asksaveasfilename(
            title="Save Log File",
            defaultextension=".log",
            filetypes=(("Log files", "*.log"), ("Text files", "*.txt"), ("All files", "*.*"))
        )
        if filename:
            self.log_file_var.set(filename)
    
    def browse_rainbow_table(self):
        filename = filedialog.askopenfilename(
            title="Select Rainbow Table File",
            filetypes=(("Pickle files", "*.pkl"), ("JSON files", "*.json"), ("All files", "*.*"))
        )
        if filename:
            self.rainbow_table_var.set(filename)
    
    def browse_save_rainbow(self):
        filename = filedialog.asksaveasfilename(
            title="Save Rainbow Table As",
            defaultextension=".pkl",
            filetypes=(("Pickle files", "*.pkl"), ("JSON files", "*.json"), ("All files", "*.*"))
        )
        if filename:
            self.save_rainbow_var.set(filename)
    
    def view_log(self):
        log_file = self.log_file_var.get()
        if log_file and os.path.exists(log_file):
            try:
                if os.name == 'nt':
                    os.startfile(log_file)
                elif os.name == 'posix':
                    os.system(f"xdg-open {log_file}")
                else:
                    messagebox.showerror("Error", "Unsupported operating system")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to open log file: {e}")
        else:
            messagebox.showerror("Error", "Log file does not exist")
    
    def update_ui(self):
        while self.running:
            attempts = self.brute_forcer.attempts
            elapsed_time = int(time.time() - self.brute_forcer.start_time) if self.brute_forcer.start_time > 0 else 0
            
            if elapsed_time > 0:
                speed = attempts / elapsed_time
            else:
                speed = 0
                
            self.attempts_var.set(f"Attempts: {attempts}")
            self.speed_var.set(f"Speed: {speed:.2f} passwords/s")
            self.time_var.set(f"Elapsed Time: {elapsed_time}s")
            
            if self.brute_forcer.found_password:
                self.log_result(f"[+] Password found: {self.brute_forcer.found_password}")
                self.log_result(f"[+] Attempts: {attempts}")
                self.log_result(f"[+] Time taken: {elapsed_time} seconds")
                self.stop_attack()
                break
                
            time.sleep(0.1)
    
    def log_message(self, message):
        self.result_text.config(state=tk.NORMAL)
        self.result_text.insert(tk.END, message + "\n")
        self.result_text.see(tk.END)
        self.result_text.config(state=tk.DISABLED)
        
    def log_result(self, message):
        timestamp = time.strftime("%H:%M:%S", time.localtime())
        self.log_message(f"[{timestamp}] {message}")
    
    def get_user_info(self):
        user_info = {}
        
        name = self.user_name_var.get().strip()
        birth_date = self.user_birth_var.get().strip()
        username = self.user_username_var.get().strip()
        company = self.user_company_var.get().strip()
        
        if name:
            user_info['name'] = name
        if birth_date:
            user_info['birth_date'] = birth_date
        if username:
            user_info['username'] = username
        if company:
            user_info['company'] = company
            
        return user_info
    
    def start_attack(self):
        if self.attack_thread and self.attack_thread.is_alive():
            messagebox.showerror("Error", "Attack already running")
            return
            
        target = self.target_entry.get().strip()
        if not target:
            messagebox.showerror("Error", "Target value cannot be empty")
            return
            
        hash_type = self.hash_type.get()
        hash_function = get_hash_function(hash_type)
        if hash_function is None:
            messagebox.showerror("Error", f"Unsupported hash type: {hash_type}")
            return
            
        mode = self.mode_var.get()
        manual_mode = mode == "4"
        
        try:
            max_length = int(self.length_var.get())
            if max_length < 1 or max_length > 16:
                messagebox.showerror("Error", "Max length must be between 1 and 16")
                return
        except ValueError:
            messagebox.showerror("Error", "Max length must be a number")
            return
            
        try:
            num_threads = int(self.threads_var.get())
            if num_threads < 1:
                messagebox.showerror("Error", "Number of threads must be at least 1")
                return
        except ValueError:
            messagebox.showerror("Error", "Number of threads must be a number")
            return
            
        dictionary_file = self.dictionary_var.get() if self.dictionary_var.get() else None
        if dictionary_file and not os.path.exists(dictionary_file):
            messagebox.showerror("Error", f"Dictionary file not found: {dictionary_file}")
            return
        
        if self.log_enabled_var.get():
            log_file = self.log_file_var.get()
            if not log_file:
                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                log_file = f"brutforce_{timestamp}.log"
                self.log_file_var.set(log_file)
            
            try:
                log_frequency = int(self.log_frequency_var.get())
            except ValueError:
                log_frequency = 1000
            
            self.brute_forcer.set_logging(
                log_file=log_file, 
                log_frequency=log_frequency,
                log_passwords=self.log_passwords_var.get()
            )
            self.view_log_btn.config(state=tk.NORMAL)
        
        rainbow_table = self.rainbow_table_var.get()
        generate_rainbow = self.generate_rainbow_var.get()
        save_rainbow = self.save_rainbow_var.get()
        
        if generate_rainbow and dictionary_file:
            if not save_rainbow:
                save_rainbow = f"{hash_type}_rainbow.pkl"
                
            try:
                self.log_result(f"Generating rainbow table from dictionary: {dictionary_file}")
                table = RainbowTable()
                
                with open(dictionary_file, 'r', encoding='utf-8', errors='ignore') as f:
                    passwords = [line.strip() for line in f if line.strip()]
                
                self.log_result(f"Loaded {len(passwords)} passwords, generating table...")
                table.generate_table_parallel(passwords, hash_function, num_threads)
                
                if table.save_table(save_rainbow):
                    self.log_result(f"Rainbow table saved to {save_rainbow}")
                    rainbow_table = save_rainbow
                else:
                    self.log_result("Error saving rainbow table")
            except Exception as e:
                self.log_result(f"Error generating rainbow table: {e}")
        
        if rainbow_table and os.path.exists(rainbow_table):
            self.brute_forcer.set_rainbow_table(rainbow_table)
            self.log_result(f"Loaded rainbow table: {rainbow_table}")
            
        user_info = self.get_user_info()
        if user_info:
            self.log_result(f"Using user information for smart attack: {', '.join(user_info.keys())}")
            
        attack_options = {
            'use_smart_attack': self.smart_attack_var.get(),
            'use_hybrid_attack': self.hybrid_attack_var.get(),
            'use_targeted_brute_force': self.targeted_var.get(),
            'optimize_charset': self.optimize_var.get(),
            'user_info': user_info
        }
            
        self.running = True
        self.progress_var.set("Attack in progress...")
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        
        self.result_text.config(state=tk.NORMAL)
        self.result_text.delete(1.0, tk.END)
        self.result_text.config(state=tk.DISABLED)
        
        self.log_result(f"Starting attack with parameters:")
        self.log_result(f"Target: {target}")
        self.log_result(f"Hash type: {hash_type}")
        self.log_result(f"Mode: {mode}")
        self.log_result(f"Max length: {max_length}")
        self.log_result(f"Threads: {num_threads}")
        
        if dictionary_file:
            self.log_result(f"Dictionary: {dictionary_file}")
        if self.log_enabled_var.get():
            self.log_result(f"Logging to: {self.log_file_var.get()}")
            
        advanced_methods = []
        if attack_options['use_smart_attack']:
            advanced_methods.append("Smart Attack")
        if attack_options['use_hybrid_attack']:
            advanced_methods.append("Hybrid Attack")
        if attack_options['use_targeted_brute_force']:
            advanced_methods.append("Targeted Brute Force")
        
        if advanced_methods:
            self.log_result(f"Advanced methods: {', '.join(advanced_methods)}")
        
        update_thread = threading.Thread(target=self.update_ui)
        update_thread.daemon = True
        update_thread.start()
        
        active_mode = '3' if manual_mode else mode
        self.attack_thread = threading.Thread(
            target=self.brute_forcer.start_attack,
            args=(target, active_mode, max_length, dictionary_file, manual_mode, hash_function, num_threads, attack_options)
        )
        self.attack_thread.daemon = True
        self.attack_thread.start()
    
    def stop_attack(self):
        if self.running:
            self.brute_forcer.running = False
            self.running = False
            self.progress_var.set("Attack stopped")
            self.start_btn.config(state=tk.NORMAL)
            self.stop_btn.config(state=tk.DISABLED)
            
            self.brute_forcer.cleanup()
            
            if self.brute_forcer.found_password:
                self.progress_var.set(f"Password found: {self.brute_forcer.found_password}")
            else:
                self.log_result("Attack stopped by user")

def main():
    root = tk.Tk()
    app = BruteForceGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main() 