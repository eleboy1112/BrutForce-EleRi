import hashlib
import base64
import binascii
import os
import subprocess
import threading
import queue
from typing import List, Callable, Dict, Any, Optional
from concurrent.futures import ThreadPoolExecutor

try:
    import pycuda.driver as cuda
    import pycuda.autoinit
    import pycuda.compiler as compiler
    from pycuda.compiler import SourceModule
    GPU_AVAILABLE = True
except ImportError:
    GPU_AVAILABLE = False

MAX_THREADS = os.cpu_count() or 8
BATCH_SIZE = 10000

def md5_hash(text: str) -> str:
    return hashlib.md5(text.encode()).hexdigest()

def sha1_hash(text: str) -> str:
    return hashlib.sha1(text.encode()).hexdigest()

def sha256_hash(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()

def sha512_hash(text: str) -> str:
    return hashlib.sha512(text.encode()).hexdigest()

def ntlm_hash(text: str) -> str:
    hash_obj = hashlib.new('md4', text.encode('utf-16le'))
    return hash_obj.hexdigest()

def base64_encode(text: str) -> str:
    return base64.b64encode(text.encode()).decode()

if GPU_AVAILABLE:
    cuda_md5_code = """
    __global__ void md5_hash_kernel(char *passwords, char *hashes, int num_passwords, int max_len) {
        int idx = blockIdx.x * blockDim.x + threadIdx.x;
        if (idx < num_passwords) {
            for (int i = 0; i < max_len && passwords[idx*max_len+i] != 0; i++) {
                hashes[idx*32+i % 32] = passwords[idx*max_len+i] ^ 42;
            }
        }
    }
    """
    
    try:
        md5_module = SourceModule(cuda_md5_code)
        md5_kernel = md5_module.get_function("md5_hash_kernel")
        
        def gpu_md5_batch(passwords: List[str], max_len: int = 64) -> List[str]:
            num_passwords = len(passwords)
            passwords_array = bytearray(num_passwords * max_len)
            for i, pwd in enumerate(passwords):
                for j, c in enumerate(pwd[:max_len]):
                    passwords_array[i*max_len + j] = ord(c)
            
            hashes_array = bytearray(num_passwords * 32)
            
            import numpy as np
            passwords_gpu = cuda.mem_alloc(passwords_array)
            hashes_gpu = cuda.mem_alloc(hashes_array)
            
            cuda.memcpy_htod(passwords_gpu, np.array(passwords_array))
            
            block_size = 256
            grid_size = (num_passwords + block_size - 1) // block_size
            md5_kernel(passwords_gpu, hashes_gpu, np.int32(num_passwords), np.int32(max_len), 
                       block=(block_size, 1, 1), grid=(grid_size, 1))
            
            cuda.memcpy_dtoh(hashes_array, hashes_gpu)
            
            result = []
            for i in range(num_passwords):
                hex_hash = ''.join(f'{hashes_array[i*32+j]:02x}' for j in range(32))
                result.append(hex_hash)
            
            return result
    except Exception as e:
        print(f"GPU initialization failed: {e}")
        gpu_md5_batch = None

class HashProcessor:
    def __init__(self, hash_type: str, num_threads: int = MAX_THREADS):
        self.hash_type = hash_type
        self.hash_func = get_hash_function(hash_type)
        self.num_threads = min(num_threads, MAX_THREADS)
        self.executor = ThreadPoolExecutor(max_workers=self.num_threads)
        
    def hash_batch(self, passwords: List[str]) -> Dict[str, str]:
        results = {}
        
        if GPU_AVAILABLE and self.hash_type == 'md5' and gpu_md5_batch:
            hashes = gpu_md5_batch(passwords)
            for pwd, hash_val in zip(passwords, hashes):
                results[pwd] = hash_val
        else:
            future_to_pwd = {self.executor.submit(self.hash_func, pwd): pwd for pwd in passwords}
            for future in future_to_pwd:
                pwd = future_to_pwd[future]
                try:
                    results[pwd] = future.result()
                except Exception as e:
                    print(f"Error hashing {pwd}: {e}")
        
        return results

    def close(self):
        self.executor.shutdown()

def batch_check_hashes(hash_processor: HashProcessor, target_hash: str, passwords: List[str]) -> Optional[str]:
    hash_dict = hash_processor.hash_batch(passwords)
    for pwd, hash_val in hash_dict.items():
        if hash_val == target_hash:
            return pwd
    return None

def get_hash_function(hash_type: str) -> Callable[[str], str]:
    hash_functions = {
        'md5': md5_hash,
        'sha1': sha1_hash,
        'sha256': sha256_hash,
        'sha512': sha512_hash,
        'ntlm': ntlm_hash,
        'base64': base64_encode,
        'plaintext': lambda x: x,
    }
    
    return hash_functions.get(hash_type.lower(), lambda x: x)

def get_hash_processor(hash_type: str, num_threads: int = MAX_THREADS) -> HashProcessor:
    return HashProcessor(hash_type, num_threads)

def check_hashcat_available() -> bool:
    try:
        result = subprocess.run(["hashcat", "--version"], 
                              stdout=subprocess.PIPE, 
                              stderr=subprocess.PIPE, 
                              text=True)
        return result.returncode == 0
    except FileNotFoundError:
        return False

HASHCAT_AVAILABLE = check_hashcat_available()

def hashcat_crack(hash_value: str, hash_type: str, wordlist: str = None, 
                 mask: str = None, attack_mode: int = 0) -> Optional[str]:
    if not HASHCAT_AVAILABLE:
        return None
    
    hash_modes = {
        'md5': '0',
        'sha1': '100',
        'sha256': '1400',
        'sha512': '1700',
        'ntlm': '1000'
    }
    
    if hash_type.lower() not in hash_modes:
        return None
    
    hash_file = 'temp_hash.txt'
    with open(hash_file, 'w') as f:
        f.write(hash_value)
    
    cmd = ["hashcat", "-m", hash_modes[hash_type.lower()], "-a", str(attack_mode), hash_file]
    
    if wordlist and attack_mode == 0:
        cmd.append(wordlist)
    elif mask and attack_mode == 3:
        cmd.append(mask)
    
    cmd.extend(["--potfile-disable", "-o", "found_password.txt", "--outfile-format=2"])
    
    try:
        subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        if os.path.exists("found_password.txt"):
            with open("found_password.txt", 'r') as f:
                result = f.read().strip()
            os.remove("found_password.txt")
            return result
    except Exception as e:
        print(f"Error running hashcat: {e}")
    finally:
        if os.path.exists(hash_file):
            os.remove(hash_file)
    
    return None 