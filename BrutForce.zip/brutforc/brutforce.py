import argparse
import itertools
import string
import time
import threading
import sys
import os
import datetime
import multiprocessing
import queue
import pickle
import json
import re
from typing import List, Iterator, Callable, Set, Dict, Tuple, Optional
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
from hash_functions import get_hash_function, get_hash_processor, HashProcessor

MAX_WORKERS = max(1, multiprocessing.cpu_count() - 1)
BATCH_SIZE = 10000

class PasswordAnalyzer:
    
    def __init__(self):
        self.patterns = {
            'dates': re.compile(r'(19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])'),
            'years': re.compile(r'(19|20)\d{2}'),
            'repeats': re.compile(r'(.)\1{2,}'),
            'sequences': re.compile(r'(abc|bcd|cde|def|efg|fgh|ghi|hij|ijk|jkl|klm|lmn|mno|nop|opq|pqr|qrs|rst|stu|tuv|uvw|vwx|wxy|xyz|012|123|234|345|456|567|678|789|890)'),
            'keyboard_rows': re.compile(r'(qwert|asdfg|zxcvb|yuiop|hjkl|nm|12345|67890)'),
        }
        
        self.char_weights = {
            '1': 0.05, '2': 0.04, '3': 0.04, '4': 0.04, '5': 0.04,
            '6': 0.03, '7': 0.03, '8': 0.03, '9': 0.03, '0': 0.05,
            'a': 0.04, 'e': 0.04, 'i': 0.04, 'o': 0.04, 'u': 0.03,
            's': 0.03, 't': 0.03, 'r': 0.03, 'n': 0.03, 'l': 0.03,
            'b': 0.02, 'c': 0.02, 'd': 0.02, 'f': 0.02, 'g': 0.02,
            'h': 0.02, 'j': 0.01, 'k': 0.01, 'm': 0.02, 'p': 0.02,
            'q': 0.01, 'v': 0.01, 'w': 0.01, 'x': 0.01, 'y': 0.01, 'z': 0.01,
            '!': 0.02, '@': 0.02, '#': 0.01, '$': 0.02, '%': 0.01,
            '&': 0.01, '*': 0.01, '?': 0.01, '.': 0.01, '_': 0.02
        }
        
        self.common_substrings = [
            "admin", "pass", "123", "qwert", "asdf", "letmein", "welcome",
            "abc", "xyz", "qaz", "aaa", "111", "000", "secret"
        ]
        
    def analyze_dictionary(self, dictionary_file: str) -> Dict[str, float]:
        frequencies = {}
        pattern_counts = {
            'dates': 0,
            'years': 0,
            'numbers': 0,
            'letters': 0,
            'specials': 0,
            'repeats': 0,
            'sequences': 0,
            'keyboard_rows': 0,
            'mixed': 0
        }
        
        try:
            with open(dictionary_file, 'r', encoding='utf-8', errors='ignore') as f:
                total_passwords = 0
                
                for line in f:
                    password = line.strip()
                    if not password:
                        continue
                        
                    total_passwords += 1
                    
                    if self.patterns['dates'].search(password):
                        pattern_counts['dates'] += 1
                    if self.patterns['years'].search(password):
                        pattern_counts['years'] += 1
                    if self.patterns['repeats'].search(password):
                        pattern_counts['repeats'] += 1
                    if self.patterns['sequences'].search(password):
                        pattern_counts['sequences'] += 1
                    if self.patterns['keyboard_rows'].search(password):
                        pattern_counts['keyboard_rows'] += 1
                    
                    has_numbers = bool(re.search(r'\d', password))
                    has_letters = bool(re.search(r'[a-zA-Z]', password))
                    has_specials = bool(re.search(r'[^a-zA-Z0-9]', password))
                    
                    if has_numbers and not has_letters and not has_specials:
                        pattern_counts['numbers'] += 1
                    elif has_letters and not has_numbers and not has_specials:
                        pattern_counts['letters'] += 1
                    elif has_specials:
                        pattern_counts['specials'] += 1
                    if has_numbers and has_letters:
                        pattern_counts['mixed'] += 1
            
            if total_passwords > 0:
                for pattern, count in pattern_counts.items():
                    frequencies[pattern] = count / total_passwords
                    
            return frequencies
            
        except Exception as e:
            print(f"Error analyzing dictionary: {e}")
            return {}
    
    def generate_smart_charset(self, target: str = None, frequency_data: Dict[str, float] = None) -> str:
        charset = ""
        
        if frequency_data:
            if frequency_data.get('dates', 0) > 0.1 or frequency_data.get('years', 0) > 0.1:
                charset += string.digits
            
            if frequency_data.get('letters', 0) > frequency_data.get('numbers', 0):
                charset += string.ascii_lowercase + string.ascii_uppercase
                charset += string.digits
            else:
                charset += string.digits
                charset += string.ascii_lowercase + string.ascii_uppercase
            
            if frequency_data.get('specials', 0) > 0.05:
                charset += string.punctuation
        else:
            charset = "1234567890" + "eationsrlhdcumpfgybwvkxjqz" + "EATIONSRLHDCUMPFGYBWVKXJQZ" + "!@#$%&*?._"
        
        return charset
    
    def suggest_password_patterns(self, target: str = None, user_info: Dict[str, str] = None) -> List[str]:
        suggestions = []
        
        if user_info:
            name = user_info.get('name', '')
            birth_date = user_info.get('birth_date', '')
            username = user_info.get('username', '')
            company = user_info.get('company', '')
            
            if name:
                suggestions.append(name.lower())
                suggestions.append(name.capitalize())
                suggestions.append(name.lower() + "123")
                
            if birth_date and len(birth_date) >= 8:
                year = birth_date[-4:]
                month = birth_date[2:4] if len(birth_date) >= 10 else ""
                day = birth_date[:2] if len(birth_date) >= 10 else ""
                
                if year.isdigit():
                    suggestions.append(year)
                    if name:
                        suggestions.append(name.lower() + year)
                
                if month.isdigit() and day.isdigit():
                    suggestions.append(day + month + year)
                    suggestions.append(year + month + day)
            
            if username:
                suggestions.append(username.lower())
                suggestions.append(username.capitalize())
                suggestions.append(username.lower() + "123")
            
            if company:
                suggestions.append(company.lower())
                suggestions.append(company.capitalize())
        
        if target:
            years = self.patterns['years'].findall(target)
            if years:
                suggestions.extend(years)
            
            for substr in self.common_substrings:
                if substr in target.lower():
                    suggestions.append(substr)
                    suggestions.append(substr + "123")
        
        return list(set(suggestions))

class RainbowTable:
    
    def __init__(self, table_file: str = None):
        self.table: Dict[str, str] = {}
        self.table_file = table_file
        if table_file and os.path.exists(table_file):
            self.load_table()
            
    def load_table(self) -> bool:
        try:
            if self.table_file.endswith('.json'):
                with open(self.table_file, 'r', encoding='utf-8') as f:
                    self.table = json.load(f)
            else:
                with open(self.table_file, 'rb') as f:
                    self.table = pickle.load(f)
            print(f"[+] Loaded rainbow table with {len(self.table):,} entries")
            return True
        except Exception as e:
            print(f"[-] Error loading rainbow table: {e}")
            return False
            
    def save_table(self, file_path: str = None) -> bool:
        if not file_path:
            file_path = self.table_file
            
        if not file_path:
            return False
            
        try:
            if file_path.endswith('.json'):
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(self.table, f)
            else:
                with open(file_path, 'wb') as f:
                    pickle.dump(self.table, f)
            print(f"[+] Saved rainbow table with {len(self.table):,} entries to {file_path}")
            return True
        except Exception as e:
            print(f"[-] Error saving rainbow table: {e}")
            return False
            
    def add_entry(self, password: str, hash_value: str) -> None:
        self.table[hash_value] = password
        
    def add_entries_batch(self, password_hash_pairs: Dict[str, str]) -> None:
        self.table.update(password_hash_pairs)
        
    def lookup(self, hash_value: str) -> Optional[str]:
        return self.table.get(hash_value)
        
    def generate_table(self, passwords: List[str], hash_function: Callable[[str], str]) -> None:
        for password in passwords:
            hash_value = hash_function(password)
            self.add_entry(password, hash_value)
            
    def generate_table_parallel(self, passwords: List[str], hash_function: Callable[[str], str], 
                              num_threads: int = MAX_WORKERS) -> None:
        batch_size = len(passwords) // num_threads
        if batch_size == 0:
            batch_size = 1
            
        password_batches = [passwords[i:i+batch_size] for i in range(0, len(passwords), batch_size)]
        
        with ThreadPoolExecutor(max_workers=num_threads) as executor:
            batch_results = list(executor.map(
                lambda batch: {hash_function(pwd): pwd for pwd in batch},
                password_batches
            ))
            
        for batch_result in batch_results:
            self.add_entries_batch(batch_result)

class BruteForce:
    def __init__(self):
        self.running = False
        self.found_password = None
        self.attempts = 0
        self.start_time = 0
        self.common_passwords = [
            "admin", "admin123", "password", "123456", "qwerty", 
            "12345678", "111111", "1234567890", "123123", "abc123",
            "1234567", "password1", "12345", "1234567", "qwerty123",
            "000000", "1q2w3e", "aa12345678", "qwerty", "q1w2e3r4",
            "user", "root", "guest", "default"
        ]
        self.log_file = None
        self.log_frequency = 1000
        self.log_passwords = False
        self.last_log_time = 0
        self.attempts_lock = threading.Lock()
        self.result_found = threading.Event()
        self.worker_pool = None
        self.rainbow_table = None
        self.password_analyzer = PasswordAnalyzer()
        self.user_info = {}
        
    def set_rainbow_table(self, table_file: str = None) -> None:
        if table_file:
            self.rainbow_table = RainbowTable(table_file)
        else:
            self.rainbow_table = None
    
    def set_user_info(self, user_info: Dict[str, str]) -> None:
        self.user_info = user_info
        
    def smart_attack(self, target_hash: str, hash_function: Callable[[str], str]) -> bool:
        print("[+] Starting smart attack...")
        if self.log_file:
            self.log_message("Starting smart attack based on user information")
        
        suggestions = self.password_analyzer.suggest_password_patterns(
            target=target_hash,
            user_info=self.user_info
        )
        
        if suggestions:
            if self.log_file:
                self.log_message(f"Generated {len(suggestions)} password suggestions")
            
            for password in suggestions:
                if not self.running or self.result_found.is_set():
                    return False
                    
                if self.try_password(target_hash, password, hash_function):
                    return True
        
        if self.log_file:
            self.log_message("Smart attack completed - no match found")
        return False
    
    def analyze_and_optimize_dictionary(self, dictionary_file: str) -> Dict[str, float]:
        print("[+] Analyzing dictionary patterns...")
        if self.log_file:
            self.log_message("Analyzing dictionary for password patterns")
            
        frequency_data = self.password_analyzer.analyze_dictionary(dictionary_file)
        
        if self.log_file and frequency_data:
            self.log_message("Dictionary analysis results:")
            for pattern, freq in frequency_data.items():
                self.log_message(f"- {pattern}: {freq:.2%}")
                
        return frequency_data
    
    def targeted_brute_force(self, target_hash: str, hash_function: Callable[[str], str], 
                           frequency_data: Dict[str, float] = None, max_length: int = 8) -> bool:
        print("[+] Starting targeted brute force attack...")
        if self.log_file:
            self.log_message("Starting targeted brute force with optimized character sets")
            
        charset = self.password_analyzer.generate_smart_charset(
            target=target_hash,
            frequency_data=frequency_data
        )
        
        if self.log_file:
            self.log_message(f"Using optimized charset: {charset[:20]}...")
            
        return self.brute_force_attack(target_hash, charset, max_length, hash_function)
    
    def hybrid_attack(self, target_hash: str, dictionary_file: str, hash_function: Callable[[str], str]) -> bool:
        print("[+] Starting hybrid attack...")
        if self.log_file:
            self.log_message("Starting hybrid attack (dictionary + mutations)")
        
        try:
            with open(dictionary_file, 'r', encoding='utf-8', errors='ignore') as f:
                base_words = [line.strip() for line in f if line.strip()]
                
            if not base_words:
                if self.log_file:
                    self.log_message("Error: Dictionary is empty")
                return False
                
            if self.log_file:
                self.log_message(f"Loaded {len(base_words)} base words for hybrid attack")
                
                common_suffixes = ['1', '123', '2023', '2024', '!', '@', '#']
                common_prefixes = ['admin', 'user']
                
                for base_word in base_words:
                    if not self.running or self.result_found.is_set():
                        return False
                
                    if self.try_password(target_hash, base_word, hash_function):
                        return True
                        
                    mutations = [
                        base_word.lower(),
                        base_word.upper(),
                        base_word.capitalize()
                    ]
                    
                    for suffix in common_suffixes:
                        mutations.append(base_word + suffix)
                        
                    for prefix in common_prefixes:
                        mutations.append(prefix + base_word)
                    
                    for password in mutations:
                        if not self.running or self.result_found.is_set():
                            return False
                            
                        if self.try_password(target_hash, password, hash_function):
                            return True
            
            if self.log_file:
                self.log_message("Hybrid attack completed - no match found")
                
        except Exception as e:
            print(f"[-] Error during hybrid attack: {e}")
            if self.log_file:
                self.log_message(f"ERROR: Hybrid attack failed: {e}")
                
        return False
    
    def rainbow_table_attack(self, target_hash: str) -> bool:
        if not self.rainbow_table:
            return False
            
        print("[+] Starting rainbow table attack...")
        if self.log_file:
            self.log_message(f"Starting rainbow table attack with {len(self.rainbow_table.table):,} entries")
            
        password = self.rainbow_table.lookup(target_hash)
        if password:
            self.attempts += 1
            self.found_password = password
            print(f"[+] Password found in rainbow table: {password}")
            if self.log_file:
                self.log_message(f"PASSWORD FOUND in rainbow table: {password}")
            return True
                
        if self.log_file:
            self.log_message("Rainbow table attack completed - no match found")
        return False
    
    def set_logging(self, log_file=None, log_frequency=1000, log_passwords=False):
        self.log_file = log_file
        self.log_frequency = log_frequency
        self.log_passwords = log_passwords
        
        if log_file:
            log_dir = os.path.dirname(log_file)
            if log_dir and not os.path.exists(log_dir):
                os.makedirs(log_dir)
                
            with open(log_file, 'w') as f:
                timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                f.write(f"=== BRUTE FORCE LOG - {timestamp} ===\n\n")
                f.write("SETTINGS:\n")
                f.write(f"- Log frequency: {log_frequency} attempts\n")
                f.write(f"- Log passwords: {log_passwords}\n\n")

    def log_message(self, message):
        if not self.log_file:
            return
            
        try:
            with open(self.log_file, 'a') as f:
                timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                f.write(f"[{timestamp}] {message}\n")
        except Exception as e:
            print(f"Error writing to log file: {e}")

    def try_password(self, target_hash: str, password: str, hash_function: Callable[[str], str]) -> bool:
        with self.attempts_lock:
            self.attempts += 1
            current_attempts = self.attempts
        
        current_hash = hash_function(password)
        
        if self.log_file and (current_attempts % self.log_frequency == 0 or current_attempts <= 10):
            current_time = time.time()
            with self.attempts_lock:
                elapsed_time = current_time - self.last_log_time if self.last_log_time > 0 else 0
                self.last_log_time = current_time
            
            attempts_per_second = self.log_frequency / elapsed_time if elapsed_time > 0 else 0
            log_msg = f"Attempt #{current_attempts} - Speed: {attempts_per_second:.2f}/s"
            
            if self.log_passwords:
                log_msg += f" - Password: {password}"
                
            self.log_message(log_msg)
        
        if target_hash == current_hash:
            self.found_password = password
            if self.log_file:
                self.log_message(f"PASSWORD FOUND: {password} (after {current_attempts} attempts)")
            self.result_found.set()
            return True
        return False

    def common_password_attack(self, target_hash: str, hash_function: Callable[[str], str]) -> bool:
        print("[+] Starting common password attack...")
        if self.log_file:
            self.log_message("Starting common password attack")
        
        for password in self.common_passwords:
            if not self.running or self.result_found.is_set():
                return False
                
            if self.try_password(target_hash, password, hash_function):
                return True
                
        if self.log_file:
            self.log_message("Common password attack completed - no match found")
        return False
        
    def _process_password_batch(self, target_hash: str, passwords: List[str], 
                               hash_function: Callable[[str], str]) -> bool:
        for password in passwords:
            if not self.running or self.result_found.is_set():
                return False
                
            if self.try_password(target_hash, password, hash_function):
                return True
        return False

    def _generate_password_batches(self, char_set: str, length: int, batch_size: int) -> Iterator[List[str]]:
        batch = []
        for combo in itertools.product(char_set, repeat=length):
            if not self.running or self.result_found.is_set():
                if batch:
                    yield batch
                return
                
            password = ''.join(combo)
            batch.append(password)
            
            if len(batch) >= batch_size:
                yield batch
                batch = []
                
        if batch:
            yield batch

    def brute_force_attack(self, target_hash: str, char_set: str, max_length: int, 
                           hash_function: Callable[[str], str], manual_mode: bool = False) -> bool:
        print(f"[+] Starting brute force attack with charset: {char_set[:10]}{'...' if len(char_set) > 10 else ''}")
        if self.log_file:
            self.log_message(f"Starting brute force attack with charset: {char_set[:10]}{'...' if len(char_set) > 10 else ''}")
            self.log_message(f"Character set size: {len(char_set)}, Max length: {max_length}")
        
        if manual_mode:
            return self.brute_force_attack_sequential(target_hash, char_set, max_length, hash_function, manual_mode)
        else:
            return self.brute_force_attack_parallel(target_hash, char_set, max_length, hash_function)
    
    def brute_force_attack_sequential(self, target_hash: str, char_set: str, max_length: int, 
                           hash_function: Callable[[str], str], manual_mode: bool = False) -> bool:
        for length in range(1, max_length + 1):
            print(f"[+] Trying length: {length}")
            if self.log_file:
                self.log_message(f"Trying passwords of length: {length}")
                
                combinations = len(char_set) ** length
                self.log_message(f"Possible combinations for length {length}: {combinations:,}")
            
            for combo in itertools.product(char_set, repeat=length):
                if not self.running:
                    return False
                    
                password = ''.join(combo)
                
                if manual_mode:
                    print(f"Trying: {password}")
                    input("Press Enter to continue or Ctrl+C to stop...")
                
                if self.try_password(target_hash, password, hash_function):
                    return True
            
            if self.log_file:
                self.log_message(f"Completed length {length} - no match found")
                    
        return False
    
    def brute_force_attack_parallel(self, target_hash: str, char_set: str, max_length: int, 
                                   hash_function: Callable[[str], str]) -> bool:
        if self.worker_pool is None:
            self.worker_pool = ThreadPoolExecutor(max_workers=MAX_WORKERS)
        
        self.result_found.clear()
        
        for length in range(1, max_length + 1):
            if not self.running or self.result_found.is_set():
                break
                
            print(f"[+] Trying length: {length}")
            if self.log_file:
                self.log_message(f"Trying passwords of length: {length}")
                
                combinations = len(char_set) ** length
                self.log_message(f"Possible combinations for length {length}: {combinations:,}")
                self.log_message(f"Using {MAX_WORKERS} parallel workers")
            
            futures = []
            for batch in self._generate_password_batches(char_set, length, BATCH_SIZE):
                if not self.running or self.result_found.is_set():
                    break
                    
                future = self.worker_pool.submit(
                    self._process_password_batch, 
                    target_hash, 
                    batch, 
                    hash_function
                )
                futures.append(future)
                
                completed_futures = [f for f in futures if f.done()]
                for future in completed_futures:
                    futures.remove(future)
                    try:
                        if future.result():
                            return True
                    except Exception as e:
                        print(f"Error in worker thread: {e}")
            
            for future in futures:
                try:
                    if future.result():
                        return True
                except Exception as e:
                    print(f"Error in worker thread: {e}")
            
            if self.log_file:
                self.log_message(f"Completed length {length} - no match found")
        
        return False

    def dictionary_attack(self, target_hash: str, dictionary_file: str, hash_function: Callable[[str], str]) -> bool:
        print(f"[+] Starting dictionary attack using: {dictionary_file}")
        if self.log_file:
            self.log_message(f"Starting dictionary attack using: {dictionary_file}")
        
        try:
            with open(dictionary_file, 'r', encoding='utf-8', errors='ignore') as f:
                total_words = sum(1 for _ in f)
            
            if self.log_file:
                self.log_message(f"Dictionary contains {total_words:,} words")
            
            if total_words < 10000:
                return self.dictionary_attack_sequential(target_hash, dictionary_file, hash_function, total_words)
            else:
                return self.dictionary_attack_parallel(target_hash, dictionary_file, hash_function, total_words)
                
        except FileNotFoundError:
            print(f"[-] Dictionary file not found: {dictionary_file}")
            if self.log_file:
                self.log_message(f"ERROR: Dictionary file not found: {dictionary_file}")
            
        return False
        
    def dictionary_attack_sequential(self, target_hash: str, dictionary_file: str, 
                                    hash_function: Callable[[str], str], total_words: int) -> bool:
        with open(dictionary_file, 'r', encoding='utf-8', errors='ignore') as f:
            word_count = 0
            for line in f:
                if not self.running or self.result_found.is_set():
                    return False
                
                word_count += 1
                if word_count % 100000 == 0 and self.log_file:
                    self.log_message(f"Dictionary progress: {word_count:,}/{total_words:,} words checked ({word_count/total_words*100:.1f}%)")
                    
                password = line.strip()
                if self.try_password(target_hash, password, hash_function):
                    return True
                    
        if self.log_file:
            self.log_message("Dictionary attack completed - no match found")
        return False
        
    def _load_dictionary_chunk(self, file_path: str, chunk_size: int, offset: int = 0) -> List[str]:
        passwords = []
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                for _ in range(offset):
                    next(f, None)
                
                for _ in range(chunk_size):
                    line = next(f, None)
                    if line is None:
                        break
                    passwords.append(line.strip())
                    
        except Exception as e:
            print(f"Error loading dictionary chunk: {e}")
            
        return passwords
    
    def dictionary_attack_parallel(self, target_hash: str, dictionary_file: str, 
                                  hash_function: Callable[[str], str], total_words: int) -> bool:
        if self.worker_pool is None:
            self.worker_pool = ThreadPoolExecutor(max_workers=MAX_WORKERS)
        
        self.result_found.clear()
        
        chunk_size = min(100000, max(1000, total_words // (MAX_WORKERS * 2)))
        
        offset = 0
        futures = []
        
        while offset < total_words and self.running and not self.result_found.is_set():
            passwords = self._load_dictionary_chunk(dictionary_file, chunk_size, offset)
            if not passwords:
                break
                
            if offset % 100000 == 0 and self.log_file:
                self.log_message(f"Dictionary progress: {offset:,}/{total_words:,} words loaded ({offset/total_words*100:.1f}%)")
                
            future = self.worker_pool.submit(
                self._process_password_batch,
                target_hash,
                passwords,
                hash_function
            )
            futures.append(future)
            
            completed_futures = [f for f in futures if f.done()]
            for future in completed_futures:
                futures.remove(future)
                try:
                    if future.result():
                        return True
                except Exception as e:
                    print(f"Error in dictionary worker thread: {e}")
            
            offset += len(passwords)
            
        for future in futures:
            try:
                if future.result():
                    return True
            except Exception as e:
                print(f"Error in dictionary worker thread: {e}")
        
        if self.log_file:
            self.log_message("Dictionary attack completed - no match found")
            
        return False

    def display_progress(self):
        last_attempts = 0
        last_time = time.time()
        
        while self.running:
            if self.start_time == 0:
                time.sleep(1)
                continue
                
            current_attempts = self.attempts
            current_time = time.time()
            
            attempts_diff = current_attempts - last_attempts
            time_diff = current_time - last_time
            
            if time_diff >= 1:
                speed = attempts_diff / time_diff
                elapsed_time = max(1, int(current_time - self.start_time))
                
                status_line = f"\r[*] Attempted: {current_attempts} | Speed: {speed:.2f}/s | Time elapsed: {elapsed_time}s"
                print(status_line, end="")
                
                last_attempts = current_attempts
                last_time = current_time
            
            time.sleep(0.1)
            
        print()
    
    def cleanup(self):
        self.running = False
        if self.worker_pool:
            self.worker_pool.shutdown(wait=False)
            self.worker_pool = None

    def start_attack(self, target_hash: str, mode: str, max_length: int = 8, 
                     dictionary_file: str = None, manual_mode: bool = False,
                     hash_function: Callable[[str], str] = lambda x: x,
                     num_threads: int = MAX_WORKERS,
                     attack_options: Dict[str, any] = None):
        self.running = True
        self.start_time = time.time()
        self.attempts = 0
        self.last_log_time = time.time()
        self.result_found.clear()
        
        options = {
            'use_smart_attack': False,
            'use_hybrid_attack': False,
            'use_targeted_brute_force': False,
            'optimize_charset': False,
            'user_info': {}
        }
        
        if attack_options:
            options.update(attack_options)
        
        if options['user_info']:
            self.set_user_info(options['user_info'])
        
        if self.log_file:
            self.log_message(f"Starting attack with target hash: {target_hash}")
            self.log_message(f"Mode: {mode}, Max length: {max_length}, Manual mode: {manual_mode}")
            self.log_message(f"Using up to {num_threads} parallel workers")
            
            if options['use_smart_attack']:
                self.log_message("Smart attack enabled")
            if options['use_hybrid_attack'] and dictionary_file:
                self.log_message("Hybrid attack enabled")
            if options['use_targeted_brute_force']:
                self.log_message("Targeted brute force enabled")
        
        if not manual_mode:
            progress_thread = threading.Thread(target=self.display_progress)
            progress_thread.daemon = True
            progress_thread.start()
        
        try:
            if not manual_mode and self.worker_pool is None:
                self.worker_pool = ThreadPoolExecutor(max_workers=num_threads)
            
            if self.rainbow_table and self.rainbow_table_attack(target_hash):
                return self.found_password
                
            if options['use_smart_attack'] and self.smart_attack(target_hash, hash_function):
                return self.found_password
            
            if self.common_password_attack(target_hash, hash_function):
                return self.found_password
            
            frequency_data = None
            if dictionary_file and (options['use_targeted_brute_force'] or options['optimize_charset']):
                frequency_data = self.analyze_and_optimize_dictionary(dictionary_file)
                
            if dictionary_file and options['use_hybrid_attack']:
                if self.hybrid_attack(target_hash, dictionary_file, hash_function):
                    return self.found_password
            elif dictionary_file and self.dictionary_attack(target_hash, dictionary_file, hash_function):
                return self.found_password
                
            if mode == "1":
                char_set = string.digits
            elif mode == "2":
                char_set = string.ascii_letters
            elif mode == "3":
                char_set = string.digits + string.ascii_letters + string.punctuation
            else:
                print(f"[-] Unknown mode: {mode}")
                if self.log_file:
                    self.log_message(f"ERROR: Unknown mode: {mode}")
                return None
            
            if options['use_targeted_brute_force'] and frequency_data:
                if self.targeted_brute_force(target_hash, hash_function, frequency_data, max_length):
                    return self.found_password
            elif self.brute_force_attack(target_hash, char_set, max_length, hash_function, manual_mode):
                return self.found_password
                
        except KeyboardInterrupt:
            print("\n[!] Attack interrupted by user")
            if self.log_file:
                self.log_message("Attack interrupted by user")
        finally:
            self.running = False
            
            if self.log_file:
                end_time = time.time()
                duration = int(end_time - self.start_time)
                self.log_message(f"Attack completed. Duration: {duration}s, Total attempts: {self.attempts}")
                
                if self.found_password:
                    self.log_message(f"Result: Password found: {self.found_password}")
                else:
                    self.log_message("Result: No password found")
            
        return None

def main():
    parser = argparse.ArgumentParser(description='Brute Force Password Cracker')
    parser.add_argument('--target', '-t', required=True, help='Target hash or plaintext to match')
    parser.add_argument('--mode', '-m', required=True, choices=['1', '2', '3', '4'], 
                        help='Mode: 1=digits only, 2=letters only, 3=all chars, 4=manual mode')
    parser.add_argument('--length', '-l', type=int, default=8, help='Maximum password length to try')
    parser.add_argument('--dictionary', '-d', help='Path to dictionary file for wordlist attack')
    parser.add_argument('--hash-type', '-ht', default='plaintext', 
                       choices=['plaintext', 'md5', 'sha1', 'sha256', 'sha512', 'ntlm', 'base64'],
                       help='Hash type to use for comparison')
    parser.add_argument('--log-file', '-lf', help='Save log to file')
    parser.add_argument('--log-frequency', '-lfreq', type=int, default=1000, 
                       help='How often to log attempts (default: every 1000 attempts)')
    parser.add_argument('--log-passwords', '-lp', action='store_true', 
                       help='Include attempted passwords in log (WARNING: creates large logs)')
    parser.add_argument('--threads', '-th', type=int, default=MAX_WORKERS,
                       help=f'Number of parallel threads to use (default: {MAX_WORKERS})')
    parser.add_argument('--rainbow-table', '-rt', help='Path to rainbow table file (.pkl or .json)')
    parser.add_argument('--generate-rainbow', '-gr', action='store_true',
                       help='Generate rainbow table from dictionary and save')
    parser.add_argument('--save-rainbow', '-sr', help='Path to save generated rainbow table')
    
    parser.add_argument('--smart-attack', '-sa', action='store_true',
                      help='Enable smart attack based on target analysis')
    parser.add_argument('--hybrid-attack', '-ha', action='store_true',
                      help='Enable hybrid attack (dictionary + mutations)')
    parser.add_argument('--optimize', '-o', action='store_true',
                      help='Optimize character sets based on dictionary analysis')
    parser.add_argument('--targeted', '-tg', action='store_true',
                      help='Enable targeted brute force with optimized character sets')
    
    parser.add_argument('--user-name', '-un', help='User\'s name for smart attack')
    parser.add_argument('--user-birth', '-ub', help='User\'s birthdate (DDMMYYYY) for smart attack')
    parser.add_argument('--user-company', '-uc', help='User\'s company for smart attack')
    parser.add_argument('--user-username', '-uu', help='User\'s username for smart attack')
    
    args = parser.parse_args()
    
    brute_forcer = BruteForce()
    
    if args.log_file:
        if args.log_file is True:
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            args.log_file = f"brutforce_{timestamp}.log"
            
        brute_forcer.set_logging(
            log_file=args.log_file,
            log_frequency=args.log_frequency,
            log_passwords=args.log_passwords
        )
    
    hash_function = get_hash_function(args.hash_type)
    if hash_function is None:
        print(f"[-] Unsupported hash type: {args.hash_type}")
        return
    
    if args.generate_rainbow and args.dictionary:
        print("[+] Generating rainbow table from dictionary...")
        table = RainbowTable()
        
        with open(args.dictionary, 'r', encoding='utf-8', errors='ignore') as f:
            passwords = [line.strip() for line in f]
            
        table.generate_table_parallel(passwords, hash_function, args.threads)
        
        save_path = args.save_rainbow or f"{args.hash_type}_rainbow.pkl"
        if table.save_table(save_path):
            print(f"[+] Rainbow table saved to {save_path}")
            
        if not args.target:
            return
    
    if args.rainbow_table:
        brute_forcer.set_rainbow_table(args.rainbow_table)
    
    user_info = {}
    if args.user_name:
        user_info['name'] = args.user_name
    if args.user_birth:
        user_info['birth_date'] = args.user_birth
    if args.user_company:
        user_info['company'] = args.user_company
    if args.user_username:
        user_info['username'] = args.user_username
    
    attack_options = {
        'use_smart_attack': args.smart_attack,
        'use_hybrid_attack': args.hybrid_attack,
        'use_targeted_brute_force': args.targeted,
        'optimize_charset': args.optimize,
        'user_info': user_info
    }
    
    manual_mode = args.mode == '4'
    active_mode = '3' if manual_mode else args.mode
    
    print("=" * 50)
    print("BRUTE FORCE PASSWORD CRACKER")
    print("=" * 50)
    print(f"Target: {args.target}")
    print(f"Mode: {args.mode}")
    print(f"Hash Type: {args.hash_type}")
    print(f"Max Length: {args.length}")
    if args.dictionary:
        print(f"Dictionary: {args.dictionary}")
    if args.log_file:
        print(f"Log File: {args.log_file}")
    if args.rainbow_table:
        print(f"Rainbow Table: {args.rainbow_table}")
    print(f"Using {args.threads} threads")
    
    attack_methods = []
    if args.smart_attack:
        attack_methods.append("Smart Attack")
    if args.hybrid_attack:
        attack_methods.append("Hybrid Attack")
    if args.targeted:
        attack_methods.append("Targeted Brute Force")
    if attack_methods:
        print(f"Advanced methods: {', '.join(attack_methods)}")
        
    if user_info:
        print("User information provided for smart attack")
        
    print("=" * 50)
    
    try:
        password = brute_forcer.start_attack(
            args.target, 
            active_mode,
            args.length,
            args.dictionary,
            manual_mode,
            hash_function,
            args.threads,
            attack_options
        )
        
        if password:
            print(f"\n[+] Password found: {password}")
            print(f"[+] Time taken: {int(time.time() - brute_forcer.start_time)} seconds")
            print(f"[+] Attempts: {brute_forcer.attempts}")
        else:
            print("\n[-] Password not found")
    finally:
        brute_forcer.cleanup()
    
if __name__ == "__main__":
    main() 